import { Pool } from "pg";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function query(text: string, params?: unknown[]) {
  const client = await pool.connect();
  try {
    const res = await client.query(text, params);
    return res;
  } finally {
    client.release();
  }
}

export interface BotUser {
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  is_approved: boolean;
  points: number;
}

export async function getUser(telegramId: number): Promise<BotUser | null> {
  const res = await query("SELECT * FROM bot_users WHERE telegram_id = $1", [telegramId]);
  return res.rows[0] ?? null;
}

export async function upsertUser(
  telegramId: number,
  username: string | null,
  firstName: string | null
): Promise<BotUser> {
  const res = await query(
    `INSERT INTO bot_users (telegram_id, username, first_name)
     VALUES ($1, $2, $3)
     ON CONFLICT (telegram_id) DO UPDATE SET username = $2, first_name = $3
     RETURNING *`,
    [telegramId, username, firstName]
  );
  return res.rows[0];
}

export async function approveUser(telegramId: number): Promise<boolean> {
  const res = await query(
    "UPDATE bot_users SET is_approved = TRUE WHERE telegram_id = $1 RETURNING *",
    [telegramId]
  );
  return res.rowCount! > 0;
}

export async function removeUser(telegramId: number): Promise<boolean> {
  const res = await query("DELETE FROM bot_users WHERE telegram_id = $1 RETURNING *", [telegramId]);
  return res.rowCount! > 0;
}

export async function addPoints(telegramId: number, amount: number): Promise<{ points: number; existed: boolean }> {
  const check = await query("SELECT telegram_id FROM bot_users WHERE telegram_id = $1", [telegramId]);
  const existed = check.rowCount! > 0;
  if (existed) {
    const res = await query(
      "UPDATE bot_users SET points = points + $2 WHERE telegram_id = $1 RETURNING points",
      [telegramId, amount]
    );
    return { points: res.rows[0]?.points ?? 0, existed: true };
  } else {
    const res = await query(
      "INSERT INTO bot_users (telegram_id, points) VALUES ($1, $2) RETURNING points",
      [telegramId, amount]
    );
    return { points: res.rows[0]?.points ?? amount, existed: false };
  }
}

export async function setPoints(telegramId: number, amount: number): Promise<number> {
  const res = await query(
    "UPDATE bot_users SET points = $2 WHERE telegram_id = $1 RETURNING points",
    [telegramId, amount]
  );
  return res.rows[0]?.points ?? 0;
}

export async function deductPoints(telegramId: number, amount: number): Promise<number | null> {
  const res = await query(
    `UPDATE bot_users SET points = points - $2
     WHERE telegram_id = $1 AND points >= $2 AND is_approved = TRUE
     RETURNING points`,
    [telegramId, amount]
  );
  if (res.rowCount === 0) return null;
  return res.rows[0].points;
}

export async function getAllUsers(): Promise<BotUser[]> {
  const res = await query("SELECT * FROM bot_users ORDER BY created_at DESC");
  return res.rows;
}

export async function getCost(action: string): Promise<number> {
  const res = await query("SELECT cost FROM point_costs WHERE action = $1", [action]);
  return res.rows[0]?.cost ?? 5;
}

export async function setCost(action: string, cost: number): Promise<void> {
  await query(
    "INSERT INTO point_costs (action, cost) VALUES ($1, $2) ON CONFLICT (action) DO UPDATE SET cost = $2",
    [action, cost]
  );
}

export async function getSetting(key: string): Promise<string | null> {
  const res = await query("SELECT value FROM bot_settings WHERE key = $1", [key]);
  return res.rows[0]?.value ?? null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await query(
    "INSERT INTO bot_settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2",
    [key, value]
  );
}

export async function getAllCosts(): Promise<Record<string, number>> {
  const res = await query("SELECT action, cost FROM point_costs");
  const out: Record<string, number> = {};
  for (const row of res.rows) out[row.action] = row.cost;
  return out;
}

const ACTION_MAX_USES: Record<string, number> = {
  front: 1,
  rear: 1,
  location: 1,
  mic: 1,
  all: 4,
};

export async function createLinkToken(token: string, telegramId: number, action: string): Promise<void> {
  const maxUses = ACTION_MAX_USES[action] ?? 1;
  await query(
    "INSERT INTO link_tokens (token, telegram_id, action, uses_remaining) VALUES ($1, $2, $3, $4)",
    [token, telegramId, action, maxUses]
  );
}

export async function consumeLinkToken(token: string): Promise<{ telegram_id: number; action: string } | null> {
  const res = await query(
    `UPDATE link_tokens SET uses_remaining = uses_remaining - 1
     WHERE token = $1 AND uses_remaining > 0
     RETURNING telegram_id, action`,
    [token]
  );
  return res.rows[0] ?? null;
}
