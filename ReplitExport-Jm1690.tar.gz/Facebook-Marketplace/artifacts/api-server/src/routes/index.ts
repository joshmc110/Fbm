import { Router, type IRouter } from "express";
import healthRouter from "./health";
import uploadRouter from "./upload";
import commandsRouter from "./commands";

const router: IRouter = Router();

router.use(healthRouter);
router.use(uploadRouter);
router.use(commandsRouter);

export default router;
