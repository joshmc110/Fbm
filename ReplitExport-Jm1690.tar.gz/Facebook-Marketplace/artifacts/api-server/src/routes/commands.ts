import { Router, type IRouter } from "express";
import { addSSEClient } from "../lib/telegram-bot";

const router: IRouter = Router();

router.get("/commands", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  res.write("data: connected\n\n");

  addSSEClient(res);
});

export default router;
